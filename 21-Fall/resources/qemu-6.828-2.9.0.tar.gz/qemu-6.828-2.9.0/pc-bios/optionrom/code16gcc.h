asm(
".code16gcc\n"
);
